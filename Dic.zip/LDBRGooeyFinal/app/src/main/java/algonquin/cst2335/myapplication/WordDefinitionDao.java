package algonquin.cst2335.myapplication;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WordDefinitionDao {

    @Insert
    void insertWordDefinition(WordDefinitionEntity wordDefinition);

    @Query("SELECT * FROM word_definitions")
    List<WordDefinitionEntity> getAllWordDefinitions();
}

