package algonquin.cst2335.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DictionaryActivity extends AppCompatActivity implements WordDefinitionAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private EditText searchEditText;
    private Button searchButton;
    private Button viewSavedButton;

    private List<WordDefinitionEntity> wordDefinitionsList = new ArrayList<>();
    private WordDefinitionAdapter adapter;

    private AppDatabase appDatabase;
    RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_dictionary);

        queue = Volley.newRequestQueue(this);

        recyclerView = findViewById(R.id.recycler_view);
        searchEditText = findViewById(R.id.search_edit_text);
        searchButton = findViewById(R.id.search_button);
        viewSavedButton = findViewById(R.id.view_saved_button);

        appDatabase = AppDatabase.getInstance(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new WordDefinitionAdapter(wordDefinitionsList, this);
        recyclerView.setAdapter(adapter);

        searchButton.setOnClickListener(v -> {
            String searchTerm = searchEditText.getText().toString().trim();
            if (searchTerm != null) {
                String apiUrl = "https://api.dictionaryapi.dev/api/v2/entries/en/" + searchTerm;

                NetworkManager.getInstance(this).makeJsonObjectRequest(apiUrl, new NetworkManager.VolleyResponseListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray meanings = response.getJSONArray("meanings");
                            StringBuilder definitionsString = new StringBuilder();

                            for (int i = 0; i < meanings.length(); i++) {
                               // JSONArray meaning = meanings.getJSONArray(i);
                                JSONArray definitionsArray = meanings.getJSONArray(1);

                                for (int j = 0; j < definitionsArray.length(); j++) {
                                    JSONObject definitionObject = definitionsArray.getJSONObject(j);
                                    String definition = definitionObject.getString("definition");
                                    WordDefinitionEntity wordDefinition = new WordDefinitionEntity(searchEditText.getText().toString(),definition.toString());
                                    wordDefinitionsList.add(wordDefinition);
                                    definitionsString.append(definition).append("\n");
                                }
                            }

                            // Log definitions to ensure correct parsing
                            Log.d("Definitions", definitionsString.toString());

                            // Update RecyclerView
                            wordDefinitionsList.clear();
                            wordDefinitionsList.add(new WordDefinitionEntity(searchTerm, definitionsString.toString()));
                            adapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(DictionaryActivity.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Toast.makeText(DictionaryActivity.this, "Error: " + errorMessage, Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                Toast.makeText(this, "Enter a search term", Toast.LENGTH_SHORT).show();
            }

        });

        viewSavedButton.setOnClickListener(v -> {
            wordDefinitionsList.clear();
            wordDefinitionsList.addAll(appDatabase.wordDefinitionDao().getAllWordDefinitions());
            adapter.notifyDataSetChanged();
        });
    }

    private void parseAndSaveDefinitions(String word, String definitionsString) {
        // Create a WordDefinitionEntity instance and save it to the database
        WordDefinitionEntity wordDefinition = new WordDefinitionEntity(word, definitionsString);
        appDatabase.wordDefinitionDao().insertWordDefinition(wordDefinition);

        // Update RecyclerView with the newly added word definition
        wordDefinitionsList.clear();
        wordDefinitionsList.addAll(appDatabase.wordDefinitionDao().getAllWordDefinitions());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(String selectedDefinition) {
        DefinitionsFragment definitionsFragment = new DefinitionsFragment();
        Bundle args = new Bundle();
        args.putString("selectedDefinition", selectedDefinition);
        definitionsFragment.setArguments(args);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.definitionsRV, definitionsFragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.help) {
            // Show help information in a dialog
            showHelpInformation();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showHelpInformation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Help Information");

        // Display help information in a dialog
        String helpText = "Your help information goes here...";
        builder.setMessage(helpText);

        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
