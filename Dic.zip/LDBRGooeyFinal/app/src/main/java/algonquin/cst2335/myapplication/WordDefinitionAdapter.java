package algonquin.cst2335.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WordDefinitionAdapter extends RecyclerView.Adapter<WordDefinitionAdapter.ViewHolder> {

    private List<WordDefinitionEntity> wordDefinitionsList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(String item);
    }

    public WordDefinitionAdapter(List<WordDefinitionEntity> wordDefinitionsList, OnItemClickListener listener) {
        this.wordDefinitionsList = wordDefinitionsList;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView definitionTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            definitionTextView = itemView.findViewById(R.id.definitionsRV);
        }

        public void bind(final String definition, final OnItemClickListener listener) {
            definitionTextView.setText(definition);
            itemView.setOnClickListener(v -> listener.onItemClick(definition));
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_definitions, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String definition = wordDefinitionsList.get(position).getDefinitions();
        holder.bind(definition, listener);
    }

    @Override
    public int getItemCount() {
        return wordDefinitionsList.size();
    }
}
